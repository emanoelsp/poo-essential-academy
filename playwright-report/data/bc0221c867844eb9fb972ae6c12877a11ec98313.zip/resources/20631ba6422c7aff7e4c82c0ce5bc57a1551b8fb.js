(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript) <export a_ as getFirestore>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getFirestore",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a_"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript) <export a9 as doc>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "doc",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a9"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript) <export aR as collection>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "collection",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aR"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript) <export b4 as serverTimestamp>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "serverTimestamp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b4"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$firebase$2b$firestore$40$4$2e$16$2e$0_$40$firebase$2b$app$40$0$2e$15$2e$0$2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$common$2d$456515ba$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@firebase+firestore@4.16.0_@firebase+app@0.15.0/node_modules/@firebase/firestore/dist/common-456515ba.esm.js [app-client] (ecmascript)");
}),
]);