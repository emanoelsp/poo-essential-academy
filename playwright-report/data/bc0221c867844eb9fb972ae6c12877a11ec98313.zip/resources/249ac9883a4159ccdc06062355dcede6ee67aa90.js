(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1cd37yq._.js","static/chunks/0t8g_next_dist_compiled_next-devtools_index_0a68mh0.js","static/chunks/0t8g_next_dist_compiled_react-dom_199nk-b._.js","static/chunks/0t8g_next_dist_compiled_react-server-dom-turbopack_05cwcfc._.js","static/chunks/0t8g_next_dist_compiled_1stziqo._.js","static/chunks/0t8g_next_dist_client_2022wn2._.js","static/chunks/0t8g_next_dist_1ajkfzb._.js","static/chunks/0vvp_@swc_helpers_cjs_0vb02wp._.js"],
    source: "entry"
});
