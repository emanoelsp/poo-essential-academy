(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/mermaid@11.16.0/node_modules/mermaid/dist/mermaid.core.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_0gfa70v._.js",
  "static/chunks/0x5d_mermaid_dist_chunks_mermaid_core_chunk-WYO6CB5R_mjs_1u6l_62._.js",
  "static/chunks/0x5d_mermaid_dist_chunks_mermaid_core_chunk-ZIRB5QZD_mjs_0rq4850._.js",
  "static/chunks/0x5d_mermaid_dist_chunks_mermaid_core_chunk-ZGVPDNZ5_mjs_0vv2j5n._.js",
  "static/chunks/0x5d_mermaid_dist_chunks_mermaid_core_0d9q0yq._.js",
  "static/chunks/0x5d_mermaid_dist_mermaid_core_mjs_1i2riul._.js",
  "static/chunks/node_modules__pnpm_14gh0j1._.js",
  "static/chunks/0x5d_mermaid_dist_mermaid_core_mjs_1y-d-sz._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/mermaid@11.16.0/node_modules/mermaid/dist/mermaid.core.mjs [app-client] (ecmascript)");
    });
});
}),
]);