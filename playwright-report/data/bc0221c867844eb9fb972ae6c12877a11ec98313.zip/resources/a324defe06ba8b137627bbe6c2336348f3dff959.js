(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0x5d_mermaid_dist_mermaid_core_mjs_0z6xv0i._.js","static/chunks/src_components_features_course_209u-ee._.js","static/chunks/0yf-_lucide-react_dist_esm_icons_1po1mk5._.js"],
    source: "dynamic"
});
