(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/src_1ft_3gx._.js","static/chunks/0t8g_next_1nsdevl._.js","static/chunks/12bo_@firebase_auth_dist_esm_0xvkgb_._.js","static/chunks/0-jj_re2js_build_index_esm_14xux2j.js","static/chunks/0a5l_@firebase_firestore_dist_common-456515ba_esm_1em0dsn.js","static/chunks/0a5l_@firebase_firestore_dist_index_esm_1zxznu2.js","static/chunks/0a5l_@firebase_firestore_dist_common-456515ba_esm_0_uxbqh.js","static/chunks/1hn7_tailwind-merge_dist_bundle-mjs_mjs_04a_myf._.js","static/chunks/node_modules__pnpm_13olwqz._.js"],
    source: "dynamic"
});
